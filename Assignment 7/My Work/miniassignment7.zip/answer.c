// Names: Ryan Sowa and David Ma
// ID#s:  260886668 and 260913955


// Include stdlib.h, stdio.h, and string.h libraries

#include <stdlib.h>
#include<stdio.h>
#include<string.h>

// Define main function. This function essentially extracts an answer and gold amount from the payload and depending on what they are, 
// performs certain operations.

int main(void) {

		
		
		char answer[1000];
		char *data = getenv("QUERY_STRING");
		int n = strlen(data);	
		int goldpieces;
		char gold[1000];
		int j = 0;
		int i;
		int true = 0;
		for (i = 8; i < n && *(data + i) != '&'; i++) {

			answer[j] = *(data + i);
			j++;
		}
		
		
		if ( *(data + i) != '&') {
	
			true = 1;
		}			
		
		answer[j] = '\0';
		

		int k;
		int m = 0;

		for (k = i + 6; k < n; k++) {

			gold[m] = *(data + k);
			m++;
		}
		
		gold[m] = '\0';

		sscanf (gold, "%d", &goldpieces);
		
		if (true) {

			goldpieces = 10;

		}
		

		printf("Content-type:text/html\n\n");
		printf("<html>");
		

		

		if (strcmp(answer,"printf") == 0) {

			goldpieces+=10;
			
			if (goldpieces >= 100) {

				printf("You win!!");

				return 0;
			}

			printf("<a href=\"https://www.cs.mcgill.ca/~rsowa/cgi-bin/addgold.cgi?gold=%d""\">Correct answer, you earned 10 gold! Click here to return</a>",goldpieces);
		}

		if (strcmp(answer,"printf") != 0 && strcmp(answer,"WEST") != 0 && strcmp(answer,"EAST") != 0 && strcmp(answer,"NORTH") != 0 && strcmp(answer,"SOUTH") != 0 && strcmp(answer,"GOLD") != 0)
		{
			goldpieces-=5;
			

			if (goldpieces == 0) {

				printf("You die!!!!");
				return 0;
			}

			printf("<a href=\"https://www.cs.mcgill.ca/~rsowa/cgi-bin/addgold.cgi?gold=%d""\">Wrong answer, you lose 5 gold! Click here to return</a>",goldpieces);		


		}

		if (strcmp(answer,"NORTH") == 0) {
				
			if (true) {
				printf("<a href=\"https://www.cs.mcgill.ca/~mriend10/\">Press HERE to go North</a>");
			}

			else {

				printf("<a href=\"https://www.cs.mcgill.ca/~mriend10/cgi-bin/addgold.cgi?gold=%d""\">Press HERE to go North</a>",goldpieces);
			}
		}
		
		if (strcmp(answer,"SOUTH") == 0) {

			if (true) {
				

				printf("<a href=\"https://www.cs.mcgill.ca/~zshi11/\">Press HERE to go South</a>");
			}
			else {
				printf("<a href=\"https://www.cs.mcgill.ca/~zshi11/cgi-bin/addgold.cgi?gold=%d""\">Press HERE to go South</a>",goldpieces);
			}

		}

		if (strcmp(answer,"WEST") == 0) {

			if (true) {

				printf("<a href=\"https://www.cs.mcgill.ca/~hhuang80/\">Press HERE to go West</a>");
			}

			else {
				printf("<a href=\"https://www.cs.mcgill.ca/~hhuang80/cgi-bin/addgold.cgi?gold=%d""\">Press HERE to go West</a>",goldpieces);
			}
		}
		
		if (strcmp(answer,"EAST") == 0) {

			if (true) {


				printf("<a href=\"https://www.cs.mcgill.ca/~ysavas/\">Press HERE to go East</a>");

			}

			else {
				printf("<a href=\"https://www.cs.mcgill.ca/~ysavas/cgi-bin/addgold.cgi?gold=%d""\">Press HERE to go East</a>",goldpieces);

			}

		}

		if (strcmp(answer, "GOLD") == 0) {
			
			if (true) {


				printf("<a href=\"https://www.cs.mcgill.ca/~rsowa/cgi-bin/addgold.cgi?gold=10\">You have 10 goldpieces</a>");
			}

			else {

				printf("<a href=\"https://www.cs.mcgill.ca/~rsowa/cgi-bin/addgold.cgi?gold=%d""\">You have %d"" goldpieces</a>",goldpieces, goldpieces);

			}
			
		}

		printf("<head><title>Answer Page</title></head>");		
		printf("</html>");
		
		return 0;	

	}
