// Name: Ryan Sowa
// ID#: 260886668


// Include stdio.h, stdlib.h, and time.h libraries

#include<stdio.h>
#include<stdlib.h>
#include <time.h>

// Define local variables "rows" and "cols"

int rows = 5;
int cols = 5;

// Define the "fillMatrix" function. This function generates random numbers from 1 to 100 and stores them in a 2d array or a "matrix".

void fillMatrix(int matrix[rows][cols]) {
	
	int i, j;
	srand (clock());

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			matrix[i][j] = rand() % 100 + 1;

		}

	}

}

// Define the "printMatrix" function. This function prints the contents of a given matrix.

void printMatrix(int matrix[rows][cols]) {

	printf("\n");
	printf("{\n");
	int i, j;

	for (i = 0; i < rows; i++) {
		printf("	{");
		for (j = 0; j < cols; j++) {
			if (j == cols - 1) {
				printf("%d},", *(*(matrix + i) + j));
			} else {
				printf("%d,", *(*(matrix + i) + j));
			}
			
		}
	printf("\n");
	}
	printf("}\n");
}


// Define the "transposeMatrix" function. This function "transposes" or swaps the rows and columns of a given matrix.

void transposeMatrix(int matrix[rows][cols]) {

	int i, j, temp, n;
	
	n = 0;

	for (i = 0; i < rows; i++) {
		for (j = n; j < cols; j++) {
		
			temp = *(*(matrix + i) + j);
			*(*(matrix + i) + j) = *(*(matrix + j) + i);
			*(*(matrix + j) + i) = temp;		
		}
		n++;
	}


}


// Define the "multiplyMatrix" function. This function multiplies two matrices and stores the result in "resultMatrix".

void multiplyMatrix(int m1[2][cols],
		    int m2[rows][cols],
		    int resultMatrix[rows][cols]) {


	int i, j,k,l,multiply,cellValue;
	cellValue = 0;
	
	for (i = 0; i < 2; i++) {

		k = 0;

		while (k != 5) {

			for (j = 0; j < cols; j++) {
			
				multiply = m1[i][j] * m2[j][k];
				cellValue = multiply + cellValue;
				
			}

			resultMatrix[i][k] = cellValue;
			k++;
			cellValue = 0;
		}			
	}

	for (i = 2; i < rows; i++) {
		for (j = 0; j < cols; j++) {
			resultMatrix[i][j] = 0;
		}
	}
}




// Define the main function. This function calls the functions defined above and returns an error code of 0 at the end. 

int main() {

	int matrix[rows][cols];

	fillMatrix(matrix);
	printMatrix(matrix);

	transposeMatrix(matrix);
	printMatrix(matrix);
	
	int matrix2[2][5]={0,1,2,3,4,5,6,7,8,9};
	int matrixResult[rows][cols];

	multiplyMatrix(matrix2, matrix, matrixResult);
	printMatrix(matrixResult);

	return 0;

}
