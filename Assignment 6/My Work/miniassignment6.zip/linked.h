// Name: Ryan Sowa
// ID#: 260886668

// Define findUpdate and prettyPrint functions for use in main.c

void findUpdate(int account, int amount);
void prettyPrint();
