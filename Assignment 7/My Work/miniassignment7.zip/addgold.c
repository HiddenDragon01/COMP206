// Names: Ryan Sowa and David Ma
// ID#s:  260886668 and 260913955

// Include stdlib.h, stdio.h, string.h, and math.h libraries

#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<math.h>

// Define main function

int main(void)
{
	// Start printing to the screen in html
	printf("Content-type:text/html\n\n");

	// Define variables goldpieces and gold
	int goldpieces;
	char gold[1000];

	// Extract the payload using "getenv" and store in data
	char *data = getenv("QUERY_STRING");

	// Get the length of data
	int n = strlen(data);	
	
	// Make a counter, j, and initialize to zero
	int j = 0;
	
	// Set gold equal the amount specificed in the payload
	for (int i = 5; i < n; i++) {

		gold[j] = *(data + i);
		j++;		
	}

	// Add a null terminator at the end
	gold[j] = '\0';

	// Add the integer value from the char array into the integer goldpieces
	sscanf(gold, "%d", &goldpieces);

	// Open index.html
	FILE *p = fopen("../index.html", "rt");
	
	// define an array "str" which holds data from fgets
	char str[1000];
	

	fgets(str,999,p);
	
	// While not at the end of the file, read and print all the data from index.html. Add an additional line to set the value of the goldpieces.
	while (!feof(p)) {
			
			
		if ((strstr(str, "</form>")) != NULL) {
			

			printf("<input type=\"hidden\" name=\"gold\" value=\"%d\">", goldpieces);
			

		 } 


		printf("%s", str);

		

		
		fgets(str,999,p);




	}

	// Close the file and return a 0 error code
	
	fclose(p);
	return 0;
}
