#!/bin/bash

gcc -o database database.c
