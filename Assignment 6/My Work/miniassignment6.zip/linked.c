// Name: Ryan Sowa
// ID#: 260886668

// Include stdio.h and stdlib.h libraries

#include<stdio.h>
#include<stdlib.h>

// Define a struct ACCOUNT which has the fields accountNumber, balance, and struct pointer next

struct ACCOUNT {

	int accountNumber;
	float balance;
	struct ACCOUNT *next;
};

// Define pointers to point to the head and tail of the linked list

struct ACCOUNT *head = NULL;
struct ACCOUNT *tail = NULL;


// Define findUpdate which will update the linked list's accountNumber and balance fields

void findUpdate(int account, float amount) {
	

	// define a pointer temp which pointes to a node with accountNumber = account and balance = amount

	struct ACCOUNT *temp = (struct ACCOUNT*) malloc(sizeof(struct ACCOUNT));

	temp->accountNumber = account;

	temp->balance = amount;

	// If head is NULL or the linked list is empty, then set head and tail to temp and assign the "next" field for temp to "NULL".
	// This is essentially creating the first node in the linked list.

	if (head == NULL) {

		head = temp;
		tail = temp;
		tail->next = NULL;
	}

	// Else, check if one of the nodes in the linked list's accountNumber field is equal to account. If it is, update the balance number.
	// If there exists no node in the linked list whose accountNumber is equal to account, then create a new node with accountNumber = account
	// and balance = amount. Update the head and tail pointers correspondingly.

	else {

		
		struct ACCOUNT *pointer = head; 
		while (pointer != NULL) {

			if (pointer->accountNumber == account) {

				pointer->balance = pointer->balance + amount;
				return;
			} 

			pointer = pointer->next;
		}

		tail->next = temp;
		
		tail = tail->next;

		tail->next = NULL;

	}


}

// In prettyPrint, define a pointer equal to the head of the linked list. While the pointer is not NULL (or not at the end of the linked list)
// print the accountNumber and balance to the user, right justified. Move the pointer to its "next" field each iteration.


void prettyPrint(){

	struct ACCOUNT *pointer = head;
	while (pointer != NULL) {

		// Make sure balance prints two decimal places

		printf("ACCOUNT ID: %-5d BALANCE: $%-9.2f\n", pointer->accountNumber, pointer->balance);
		
		pointer = pointer->next;
	}

}
