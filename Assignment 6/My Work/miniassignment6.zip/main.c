// Name: Ryan Sowa
// ID#: 260886668

// include stdio.h and string.h libraries as well as ssv.h and linked.h header files

#include<stdio.h>
#include<string.h>
#include "ssv.h"
#include "linked.h"

// In the main function, open the file. Read each line of the file into the "parse" function in ssv.h to get "acct" and "amnt" fields.
// Then, call "findUpdate" from linked.c which will print those updated fields to the user. Lastly, close the file and return a 0 error
// code.

int main() {

	int acct;
	float amnt;
	char data[1000];

	FILE *x = fopen("mini6tester.ssv","rt");

	while(fgets(data,sizeof data, x)) {
		
		// Don't read in an empty line

		if (data[0] == '\n') {
			
			break;
		}


		parse(data,&acct,&amnt);
		findUpdate(acct,amnt);

	}

	fclose(x);
	
	prettyPrint();


	return 0;
}

