/*
Lab I - Fork (Solution 1)

In this C-Code, we are using the shared memory as a medium to share information between forked processes.
The other solution uses shell memory as a medium for forked processes to intercommunicate. But for now, the shell memory method is not working
due to a configuration on the server.

The textfile method is not covered as it's in the lecture slides.
*/

#include <stdlib.h> 
#include <sys/types.h> 
#include <unistd.h>
#include <stdio.h> 
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

struct SharedMemory {   //This is the shared memory struct 
     char* turn; //Turn stores whether it's the producer's or consumer's turn
     int value; //Stores the current value iterate by the producer, to be passed to the consumer
};

void producer(struct SharedMemory * ptr){
    for (int counter = 1 ; counter <= 10; counter++)
    {
        while (strcmp(ptr->turn,"Producer")!=0); //While it's not the producer's turn, wait

        ptr->value=counter; // Set value field in the shared memory
        ptr->turn= "Consumer";   // Set the next turn to the consumer's
    }
}

void consumer(struct SharedMemory * ptr){
    while (1){
        while (strcmp(ptr->turn,"Consumer")!=0); //While it's not the consumer's turn, wait
        printf("%d ", ptr->value);
        if (ptr->value == 10 ) break; //leave loop if it's the last number
        ptr->turn = "Producer";
    }
    printf("\n");
}

int main(int argc, char const *argv[])
{
    int shm_id;   // Id for the shared memory
    struct SharedMemory *shmPTR; // Point to the shared memory
    shm_id = shmget(IPC_PRIVATE, sizeof(struct SharedMemory), IPC_CREAT | 0666);    //creating shared memory 
    int pid;
    shmPTR = (struct SharedMemory *) shmat(shm_id, NULL, 0);    //attach the shared memory by making shmPTR point to it
    shmPTR->turn = "Producer";  //First turn goes to producer

    pid = fork();   // Forks the process
    // at this point, shmPTR points to the same shared memory for both processes
    
    switch (pid) {
        case -1:    //Something went wrong
                perror("Fork");
                exit(1);
        
        case 0:   
                // This is the child branch as fork return 0 to the children. 
                // We will arbitrarily consider the consumer to be the children
                consumer(shmPTR);
                printf("Id: %d Children (Consumer) terminating...\n",pid);
                break;
        default:    
                // This is the parent branch as fork return the children pid to the parent.
                // We will arbitrarily consider the producer to be the parent
                producer(shmPTR);
                printf("Id: %d Parent (Producer) terminating...\n",pid);
    }
    return 0;
}

