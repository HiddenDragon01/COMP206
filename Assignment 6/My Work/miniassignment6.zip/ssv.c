// Name: Ryan Sowa
// ID#: 260886668

// include stdio.h library

#include<stdio.h>


// In the parse function, simply parse each line of the file from main from the "record" array into "acct" and "amnt" fields.

void parse(char record[], int *acct, float *amnt){
	

	sscanf(record,"%d %f",acct,amnt);	


}

