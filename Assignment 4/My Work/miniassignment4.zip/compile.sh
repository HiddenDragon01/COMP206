#!/bin/bash

gcc -o reverse reverse.c

gcc -o matrix matrix.c
