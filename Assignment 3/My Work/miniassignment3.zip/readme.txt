gcc command I would use to compile triangles.c: gcc -o triangles triangles.c
