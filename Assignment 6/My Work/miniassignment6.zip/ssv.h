// Name: Ryan Sowa
// ID#: 260886668

// Define parse function for use in main.c

void parse(char record[], int *acct, float *amnt);
