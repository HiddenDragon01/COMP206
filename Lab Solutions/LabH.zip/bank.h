//To make the .h file, we copy the extract struct definition
//and the function signatures from the .c file
//Since there's no function in the .c file, we just have to copy the BANK_ACCOUNT struct definition
struct BANK_ACCOUNT {
    char type; // ‘S’=savings, ‘C’=checking
    double balance;
    union ACCOUNT_SPECIFIC {
        double charge; // for withdrawal from savings accounts
        int credit_score; // for checking account
    } specific;
};
