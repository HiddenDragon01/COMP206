// Name: Ryan Sowa
// ID#: 260886668


// Include stdio.h, stdlib.h, and string.h libraries 

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// define main function

int main(int argc, char *argv[]) {
		
	// If the user did not enter three arguments, then an error message is shown

	if (argc != 3) {

		puts("Wrong number of arguments. Please input: ./reverse WORD1 WORD2.");	
		return 1;
	}	
	
	// Define integers "i", "j", "k", pointer "string", and an array of characters "reverseString" to store the reverse 	
	
	int i, j, length;
      	char *string = argv[1];
	char reverseString[100];
	
	// Set integer j equal to zero and length equal to the length of the first argument (after the file name) 

	j = 0;
	length = strlen(argv[1]);
	
	// Loop to insert everything in the reverse position in the reverseString. For example, the letter at the end would be put at the front of reverseStr	     ing, the second to last letter would become the second letter of reverseString, etc.

	for (i = length - 1; i >=0; i--) {

		reverseString[j++] = string[i];
	}

	// Make sure to add a "'\0'" at the end of the arrray	

	reverseString[j] = '\0';

	// Use "strcmp" to store the value comparing reverseString and the user's second argument (after the file name) in x

	int x = strcmp(reverseString,argv[2]);

	// If x is equal to 0, the user's second argument is the same as the reverse of the first argument. Print a message stating that this is the case.

	if (x == 0) {
		printf("WORD1=%s WORD2=%s – REVERSE\n",argv[1],argv[2]);

	// If x is not equal to 0, then the user's second argument is not the reverse of the first argument. Print a message stating that this is the case.
		
	} else {
		printf("WORD1=%s WORD2=%s - NOT REVERSE\n",argv[1],argv[2]);
	}

	// return a 0 error code

	return 0;
	}
		
