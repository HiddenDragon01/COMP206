#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

struct BANK_ACCOUNT {
    char type; // ‘S’=savings, ‘C’=checking
    double balance;
    union ACCOUNT_SPECIFIC {
        double charge; // for withdrawal from savings accounts
        int credit_score; // for checking account
    } specific;
};

int main(){
    struct BANK_ACCOUNT *accounts = (struct BANK_ACCOUNT *)calloc(100,sizeof(struct BANK_ACCOUNT));
    int nextSpot = 0;
    int newAccounts;
    printf("Please enter the number of accounts you would like to create: ");
    scanf("%d",&newAccounts);
    int choice;
    char c;
    for (int i = 0; i < newAccounts; i++)
    {
        printf("- Prompting information for bank account %d\n",i);
        struct BANK_ACCOUNT bankAcc;
        printf("    Please enter the type of the acount ('S'= Savings 'C'=Checking):");
        scanf(" %c",&bankAcc.type);
        printf("    Please enter the balance of the acount: ");
        scanf("%lf",&bankAcc.balance);
        if (bankAcc.type=='S'){
            printf("    Please enter the charge of the acount: ");
            scanf("%lf",&bankAcc.specific.charge);
        } else {
            printf("    Please enter the credit score of the acount: ");
            scanf("%d",&bankAcc.specific.credit_score);
        }
        *(accounts+i)=bankAcc;
        nextSpot++;
    }
    for (int i = 0; i < nextSpot; i++)
    {
        printf(" -- Bank Account %d --\n",i);
        printf("Type : %c\n", accounts[i].type);
        printf("Balance : %lf\n", accounts[i].balance);
        if (accounts[i].type=='S'){
            printf("Charge: %lf\n",accounts[i].specific.charge);
        } else {
            printf("Credit Score: %d\n",accounts[i].specific.credit_score);
        }
    }
    return 0;
}