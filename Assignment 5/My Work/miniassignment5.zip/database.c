// Name: Ryan Sowa
// ID#: 260886668

// include stdio.h, stdlib.h, and string.h libraries

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// define main function

int main(int argc, char *argv[]) {

	// If the user did not enter any arguments, an error message is shown and the program terminates

	if (argc == 1) {
		puts("You did not provide any arguments. Please enter: ./database CMD OPT1 OPT2 OPT3 OPT4");

		return 1;

	}

	// If the user did not enter SHOW, DELETE, or ADD as his/her first argument, an error message is shown 
	// and the program terminates

	if ((strcmp(argv[1], "SHOW")) != 0 && (strcmp(argv[1], "DELETE")) != 0 && (strcmp(argv[1],"ADD")) !=0) {
		puts("The command you requested is invalid. Please select from one of these: SHOW, DELETE, ADD");

		return 1;

	}

	// If the user's first argument was "SHOW", then data is read from "database.csv" into the "data", "id", "name", "age", 
	// and "gpa" fields and then displayed without commas to the user. 

	if ((strcmp(argv[1],"SHOW")) == 0) {
		
		char data[1000], id[300], name[300], age[300], gpa[300];

		int i,j,length,count;
		
		count = 1;	

		FILE *x = fopen("database.csv","rt");

		fgets(data,999,x);

		while(!feof(x)) {

			i = 0;
	
			for (j = 0; j < 300 && data[i] != ','; j++, i++) {

				id[j] = data[i];
				length = j+1;
			
			}

			id[length] = '\0';

			i++;

			for (j = 0; j < 300 && data[i] != ','; j++, i++) {

				name[j] = data[i];
				length = j+1;

			}

			name[length] = '\0';

			i++;

			for (j = 0; j < 300 && data[i] != ','; j++, i++) {
				

				age[j] = data[i];
				length = j+1;

			}
			age[length] = '\0';
			i++;


			for (j = 0; j < 300 && data[i] != '\n'; i++, j++) {
				
				gpa[j] = data[i];
				length = j+1;
			}

			gpa[length] = '\0';
			
			// Formating so each column of each field is directly above the last column

			printf("Record %d: ID=%-10s NAME=%-10s AGE=%-10s GPA=%-10s\n",count,id,name,age,gpa);

			count++;

			fgets(data,999,x);
		}	

		// Close the file as a good practice

		fclose(x);


		
	}

	// If the user's first command was "DELETE", then (after checks for arguments) read in data as before into the "data" and "id" fields.
	// Then, if the user's second argument matched the "id", the corresponding line would be added to a new "database.tmp" file. The old 
	// "database.csv" file would be deleted and the new "database.tmp" file renamed "database.csv". If the "id" did not match the user's 
	// second argument, then an error message would be displayed and the program terminated. 

 
	
	if ((strcmp(argv[1],"DELETE")) == 0) {
		
		// If the user entered less than two arguments, then an error message is shown and the program terminates
		// If the user entered more than two arguments, then only the first two are used

		if (argc < 3) {

			puts("Name of record to delete is missing");

			return 1;

		}

		char data[1000], id[300];

		int i, j, length;

		FILE *old = fopen("database.csv","r");

		FILE *new = fopen("database.tmp","w");

		fgets(data,999,old);

		// Keep track of whether or not id was found in the csv file

		int true = 0;

		while(!feof(old)) {

			i = 0;

			for (j = 0; j < 300 && data[i] != ','; j++, i++) {

				id[j] = data[i];
				length = j + 1;

			}

			id[length] = '\0';
			

			if (strcmp(id,argv[2]) != 0) {
			
			
				i = 0;

				for (i = 0; i < 999 && data[i] != '\n'; i++) {
					fputc(data[i], new);

				}

			fputc('\n',new);

			} else {

				// If the user's second argument was equal to the id, id was found in the csv and true is set to 1

				true = 1;

			}

			

			fgets(data,999,old);

		}
		
		// Close the file to maintain good practice

		fclose(old);
		fclose(new);

		// If the user's second argument was not equal to the id, an error message is displayed and the program terminated

		if (true == 0) {

			puts("Sorry, that user was not found. Nothing was deleted.");
			return 1;
		}

		// Delete the old "database.csv" file and rename "database.tmp" "database.csv"

		system("rm database.csv");
		system("cp database.tmp database.csv");

		

	}

	
	// If the user's first argument was "ADD", check for correct amount of arguments. If the number of arguments are satisfied, then append those 
	// arguments to the end of "database.csv"

	if ((strcmp(argv[1], "ADD")) == 0) {

		// If the user entered less than four arguments, then an error message is shown and the program terminates
		// If the user entered more than four arguments, then only the first four are used 	

		if (argc < 6) {


			puts("Missing ID, Name, AGE, and GPA arguments");
			return 1;

		}
		
		// Append the user's arguments to the end of "database.csv"

		FILE *append = fopen("database.csv", "at");
		fprintf(append, "%s,%s,%s,%s", argv[2], argv[3], argv[4], argv[5]);
		fprintf(append,"\n");

		// Close the file to maintain good practice 

		fclose(append);



	}

	return 0;
}
