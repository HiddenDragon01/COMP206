#include<stdio.h>
#include<stdlib.h>
#include<string.h>

//QUESTION ONE

int main(int argc, char const *argv[])
{
    char name[30],multipleNames[1000];
    int numberOfTimes;

    if (argc ==1) 
    {
        numberOfTimes=2;
    } else {
        numberOfTimes= atoi(argv[1]);
    }

    printf("Enter a name: ");
    scanf("%s",name);

    multipleNames[0]='\0';

    for (int i = 0; i < numberOfTimes; i++)
    {
        strcat(multipleNames,name);
    }

    printf("%s\n", multipleNames);
    return 0;
}
